package com.qt.qualithon.ui.imdb;

import com.qt.qualithon.TestSession;
import com.qt.qualithon.ui.HomePage;
import com.qt.qualithon.ui.WebApp;

/**
 * entry class to hold IMDB Web Application UI Model/Page Objects
 **/
public class WebAppImdb extends WebApp {

	public WebAppImdb(TestSession testSession) {
		super(testSession);
	}

	/**
	 * launch IMDb landing page in browser test session
	 *
	 * @return IMDb Web Home Page page object
	 **/
	public HomePage launch() {
		
			this.testSession.driver().get("https://www.imdb.com");
			return new HomePageImdb(this.testSession);		

	}
}
