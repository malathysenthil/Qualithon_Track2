package com.qt.qualithon.ui;

import com.qt.qualithon.TestSession;

public abstract class WebApp extends Page {
	
	public WebApp(TestSession testSession) {
		super(testSession);
	}
	
	public abstract HomePage launch();

}
