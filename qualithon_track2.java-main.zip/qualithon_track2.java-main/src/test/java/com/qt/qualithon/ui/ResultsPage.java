package com.qt.qualithon.ui;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.qt.qualithon.TestSession;

public abstract class ResultsPage extends Page{
	
	public ResultsPage(TestSession testSession){
        super(testSession);
    }
	
	public abstract List<WebElement> movieResultLinks();
	
	public abstract MoviePage firstMovieResult();
}
