package com.qt.qualithon.ui.imdb;

import com.qt.qualithon.TestSession;
import com.qt.qualithon.ui.MoviePage;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.NoSuchElementException;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

/**
 * page object class represents elements and actions on the IMDb Movie Page
 **/
public class MoviePageImdb extends MoviePage {

	public MoviePageImdb(TestSession testSession) {
		super(testSession);

		// adjust page for tablet formfactor
		WebElement showMoreLink = this.testSession.driverWait().until(ExpectedConditions
				.presenceOfElementLocated(By.cssSelector("a[data-testid='title-pc-expand-more-button']")));

		if (showMoreLink.isDisplayed()) {
			showMoreLink.click();
		}

	}

	/**
	 * get movie title
	 *
	 * @return movie title
	 **/
	public String title() {
		return this.testSession.driverWait()
				.until(ExpectedConditions
						.visibilityOfElementLocated(By.cssSelector("h1[data-testid='hero-title-block__title']")))
				.getText();
	}

	/**
	 * get movie director name
	 *
	 * @return movie director name
	 **/
	public String director() {
		List<WebElement> credits = this.testSession.driverWait()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("li.ipc-metadata-list__item")));

		// traverse credits sections to find the section with Directors
		for (WebElement credit : credits) {
			try {
				if (credit.findElement(By.cssSelector("span")).getText().equalsIgnoreCase("Director")) {
					// find director name from child element of section
					return credit.findElement(By.cssSelector("a")).getText();
				}
			} catch (NoSuchElementException e) {
			}
		}
		throw new NoSuchElementException("Failed to lookup Director on page");
	}

	/**
	 * get list of movie genres
	 *
	 * @return list of movie genres
	 **/
	public List<String> genres() {
		List<String> genres = new ArrayList<>();
		List<WebElement> credits = this.testSession.driverWait()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("li.ipc-metadata-list__item")));
		// traverse credits sections to find the section with Genres
		for (WebElement credit : credits) {
			try {
				if (credit.findElement(By.cssSelector("span")).getText().equalsIgnoreCase("Genres")) {
					// traverse list of Genres on page to add to genres list
					List<WebElement> genresElements = credit.findElements(By.cssSelector("a"));
					for (int i = genresElements.size() - 1; i >= 0; i--) {
						genres.add(genresElements.get(i).getText());
					}
					break;
				}
			} catch (NoSuchElementException e) {
			}
		}

		// if genres list is empty throw exception
		if (genres.isEmpty()) {
			throw new NoSuchElementException("Could not lookup genres on Movie page");
		}
		Collections.reverse(genres);
		return genres;

	}

	/**
	 * get movie release year
	 *
	 * @return movie release year
	 **/
	public String releaseYear() {
		List<WebElement> credits = this.testSession.driverWait()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("li.ipc-inline-list__item")));
		return credits.get(0).getText();

		// if MaturityRating list is empty throw exception
	}

	/**
	 * get list of movie writers
	 *
	 * @return list of movie writer names
	 **/
	public List<String> writers() {
		List<String> writers = new ArrayList<>();
				List<WebElement> credits1 = this.testSession.driverWait()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("li.ipc-metadata-list__item")));

		
		
		// traverse credits sections to find the section with Writers
		addWriter(credits1,writers);
		if (writers.isEmpty()) {
			List<WebElement> credits2 = this.testSession.driverWait()
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//*[@class='li.ipc-metadata-list__item ipc-metadata-list-item--link']")));
			
			for (WebElement credit : credits2) {
				try {
					if (credit.findElement(By.cssSelector("a")).getText().equalsIgnoreCase("Writers")) {
						// traverse list of writers on page to add to writers list
						List<WebElement> writersElements = credit.findElements(By.cssSelector("a"));
						for (int i = writersElements.size() - 1; i >= 0; i--) {
							if (!"Writers".equals(writersElements.get(i).getText()))
							writers.add(writersElements.get(i).getText());
						}
						break;
					}
				} catch (NoSuchElementException e) {
				}
			}
		}
		
		

		
		

		// if writers list is empty throw exception
		if (writers.isEmpty()) {
			throw new NoSuchElementException("Could not lookup Writers on movie page");
		}
		Collections.reverse(writers);
		return writers;
	}

	public String MaturityRating() {

		List<WebElement> credits = this.testSession.driverWait()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("li.ipc-inline-list__item")));
		return credits.get(1).getText();

		// if MaturityRating list is empty throw exception

	}

	public String RatingScore() {

		List<WebElement> credits = this.testSession.driverWait()
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(
						By.xpath("//*[@class='AggregateRatingButton__RatingScore-sc-1ll29m0-1 iTLWoV']")));

		return credits.get(0).getText();

		// if MaturityRating list is empty throw exception

	}
	
	public void addWriter(List<WebElement> credits, List<String> writers) {
		for (WebElement credit : credits) {
			try {
				if (credit.findElement(By.cssSelector("span")).getText().equalsIgnoreCase("Writers")) {
					// traverse list of writers on page to add to writers list
					List<WebElement> writersElements = credit.findElements(By.cssSelector("a"));
					for (int i = writersElements.size() - 1; i >= 0; i--) {
						writers.add(writersElements.get(i).getText());
					}
					break;
				}
			} catch (NoSuchElementException e) {
			}
		}
	}
}
