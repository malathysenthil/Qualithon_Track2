package com.qt.qualithon.ui;

import com.qt.qualithon.TestSession;

public abstract class HomePage extends Page {
	
	public HomePage(TestSession testSession){
        super(testSession);
    }
	
	public abstract ResultsPage search(String movieTitle);

}
