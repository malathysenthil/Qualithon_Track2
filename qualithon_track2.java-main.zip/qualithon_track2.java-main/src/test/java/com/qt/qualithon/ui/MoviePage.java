package com.qt.qualithon.ui;

import java.util.List;

import com.qt.qualithon.TestSession;

public abstract class MoviePage extends Page {

	public MoviePage(TestSession testSession) {
		super(testSession);
	}
	
	public abstract String title();
	
	public abstract String director();
	
	public abstract List<String> genres();
	
	public abstract String releaseYear();
	
	public abstract List<String> writers();
	
	public abstract String MaturityRating();
	
	public abstract String RatingScore();
}
